import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Plus, Download, Search, Rocket, HardDrive, FolderOpen, MoreHorizontal, CheckCircle2, Pencil, Trash2, PackageSearch, Loader2, Link as LinkIcon } from "lucide-react";

interface Build {
  id: string;
  name: string;
  version: string;
  size: string;
  image: string;
  importedAt: string;
}

export const LibraryView = () => {
  const [builds, setBuilds] = useState<Build[]>(() => {
    const saved = localStorage.getItem("wraith_builds");
    return saved ? JSON.parse(saved) : [];
  });
  const [isImporting, setIsImporting] = useState(false);
  const [showImportModal, setShowImportModal] = useState(false);
  const [importUrl, setImportUrl] = useState("");

  const saveBuilds = (newBuilds: Build[]) => {
    setBuilds(newBuilds);
    localStorage.setItem("wraith_builds", JSON.stringify(newBuilds));
  };

  const handleImport = async () => {
    if (!importUrl.includes("12.41")) {
      alert("Invalid build source. Please use the authorized Project Wraith CDN link.");
      return;
    }

    setIsImporting(true);
    // Simulate tactical synchronization
    await new Promise(resolve => setTimeout(resolve, 2500));

    const newBuild: Build = {
      id: "WRAITH-12-41",
      name: "Fortnite",
      version: "12.41",
      size: "12.41 GB",
      image: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&q=80&w=400",
      importedAt: new Date().toLocaleDateString()
    };

    saveBuilds([newBuild]);
    setIsImporting(false);
    setShowImportModal(false);
    setImportUrl("");
  };

  return (
    <div className="flex-1 pt-32 pb-12 px-12 max-w-[1400px] mx-auto w-full space-y-12">
      <motion.div 
        initial={{ opacity: 0, x: -30 }}
        animate={{ opacity: 1, x: 0 }}
        className="flex items-center justify-between"
      >
        <div className="space-y-2">
          <h1 className="text-7xl font-display font-black tracking-tight drop-shadow-xl italic text-white">Library</h1>
          <p className="text-xs font-mono text-white/30 uppercase tracking-[0.4em]">Authorized Tactical Builds Only</p>
        </div>
        <div className="flex items-center gap-3">
          <motion.button 
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setShowImportModal(true)}
            className="flex items-center gap-2 px-6 py-3 glass-pill bg-blue-500/10 border-blue-500/20 hover:bg-blue-500/20 transition-all text-blue-400 font-bold uppercase tracking-widest text-xs"
          >
            <Plus className="w-4 h-4" />
            Import Build
          </motion.button>
          <motion.button whileHover={{ y: 4 }} className="p-3 glass-pill hover:bg-white/10 transition-colors border-white/5"><Download className="w-6 h-6 text-white/40" /></motion.button>
        </div>
      </motion.div>

      <AnimatePresence>
        {builds.length > 0 ? (
          <div className="space-y-12">
            {/* Featured Version (Latest Imported) */}
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="glass-card p-10 flex gap-12 relative overflow-hidden group"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-blue-500/10 to-transparent pointer-events-none" />
              
              <motion.div 
                whileHover={{ scale: 1.05, rotate: -2 }}
                className="w-72 h-72 rounded-3xl overflow-hidden shadow-2xl relative shrink-0 z-10 border border-white/10"
              >
                <img src={builds[0].image} alt="Cover" className="w-full h-full object-cover transition-all duration-700" />
                <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                   <div className="text-4xl font-black italic tracking-tighter opacity-40">WRAITH</div>
                </div>
              </motion.div>

              <div className="flex-1 flex flex-col justify-center gap-8 z-10">
                 <div className="space-y-4">
                    <span className="text-xs font-mono font-bold uppercase tracking-widest text-blue-400">Tactical Core Active</span>
                    <h2 className="text-8xl font-display font-black tracking-tighter leading-none italic">{builds[0].name} {builds[0].version}</h2>
                 </div>

                 <div className="flex items-center gap-4">
                   <motion.button 
                     whileHover={{ scale: 1.05, x: 4 }}
                     whileTap={{ scale: 0.95 }}
                     className="px-10 py-4 bg-blue-600 hover:bg-blue-500 rounded-2xl font-black text-xl italic transition-all flex items-center gap-3 shadow-xl shadow-blue-600/20"
                   >
                     <Rocket className="w-6 h-6 fill-current" />
                     LAUNCH
                   </motion.button>
                   <button className="btn-secondary flex items-center gap-2 !px-6 !py-4">
                     <HardDrive className="w-5 h-5 text-white/60" />
                     Host
                   </button>
                   <button className="p-4 glass-pill hover:bg-white/10 border-white/5"><MoreHorizontal className="w-5 h-5 text-white/40" /></button>
                 </div>
              </div>
            </motion.div>

            {/* List Table */}
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="text-2xl font-display font-bold italic text-white/80 tracking-tight">System Inventory</h3>
                <div className="relative">
                   <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-white/20" />
                   <input 
                     type="text" 
                     placeholder="Filter nodes..." 
                     className="glass-pill pl-12 pr-6 py-3 w-80 focus:outline-none focus:ring-1 focus:ring-blue-500/30 transition-all text-sm border-white/5 bg-white/5"
                   />
                </div>
              </div>

              <div className="glass-card p-2">
                {builds.map((build) => (
                  <motion.div 
                    layout
                    key={build.id}
                    whileHover={{ backgroundColor: "rgba(255,255,255,0.02)" }}
                    className="flex items-center justify-between p-6 rounded-2xl border border-transparent hover:border-white/5 transition-all"
                  >
                    <div className="flex items-center gap-6">
                       <div className="w-16 h-16 rounded-xl overflow-hidden border border-white/10">
                          <img src={build.image} alt="Thumb" className="w-full h-full object-cover" />
                       </div>
                       <div>
                          <h4 className="text-xl font-bold font-display italic text-white">{build.name} {build.version}</h4>
                          <p className="text-[10px] font-mono text-white/20 uppercase tracking-widest">{build.size} // IMPORTED: {build.importedAt}</p>
                       </div>
                    </div>

                    <div className="flex items-center gap-2">
                       <button className="p-3 rounded-full bg-blue-500/10 text-blue-400 border border-blue-500/20"><CheckCircle2 className="w-5 h-5" /></button>
                       <button className="p-3 rounded-full bg-zinc-900/50 text-white/20 hover:text-white transition-colors border border-white/5"><Pencil className="w-5 h-5" /></button>
                       <button 
                        onClick={() => saveBuilds([])}
                        className="p-3 rounded-full bg-zinc-900/50 text-white/20 hover:text-red-500 transition-colors border border-white/5"
                       >
                        <Trash2 className="w-5 h-5" />
                       </button>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        ) : (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="h-[500px] glass-card flex flex-col items-center justify-center text-center p-12 border-dashed border-white/10"
          >
            <div className="w-24 h-24 rounded-full bg-white/5 flex items-center justify-center mb-8 border border-white/5">
               <PackageSearch className="w-10 h-10 text-white/10" />
            </div>
            <h2 className="text-4xl font-display font-black italic mb-4 text-white/80">No builds found.</h2>
            <p className="text-white/30 text-lg max-w-md font-light mb-10 leading-relaxed">
              Initialize the Wraith Core by importing an authorized tactical build from the Project Wraith CDN.
            </p>
            <motion.button 
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setShowImportModal(true)}
              className="px-12 py-5 bg-blue-600 hover:bg-blue-500 rounded-2xl font-black text-xl italic transition-all shadow-xl shadow-blue-900/20"
            >
              IMPORT INITIAL BUILD
            </motion.button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Import Modal */}
      <AnimatePresence>
        {showImportModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowImportModal(false)}
              className="absolute inset-0 bg-black/80 backdrop-blur-xl" 
            />
            
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative w-full max-w-xl glass-card p-10 space-y-8 z-10 border-white/10"
            >
              <div className="space-y-2">
                <h3 className="text-3xl font-display font-black italic text-white flex items-center gap-3">
                  <LinkIcon className="text-blue-400" />
                  Import Sequence
                </h3>
                <p className="text-sm text-white/40 font-medium">Enter the authorized tactical build URL to synchronize with Wraith Core.</p>
              </div>

              <div className="space-y-4">
                <div className="relative group">
                  <input 
                    type="text" 
                    value={importUrl}
                    onChange={(e) => setImportUrl(e.target.value)}
                    placeholder="https://cdn.cbn.lol/..."
                    className="w-full bg-black/50 border border-white/10 rounded-2xl px-6 py-5 text-lg font-mono text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all placeholder:text-white/10"
                  />
                  {importUrl.includes("12.41") && (
                    <div className="absolute right-4 top-1/2 -translate-y-1/2 flex items-center gap-2">
                       <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                       <span className="text-[10px] font-mono font-bold text-emerald-500 uppercase tracking-widest">VERIFIED</span>
                    </div>
                  )}
                </div>
                
                <div className="p-4 bg-blue-500/5 rounded-xl border border-blue-500/10">
                   <p className="text-[10px] font-mono text-blue-400/60 leading-relaxed">
                    HINT: Use the link provided by Project Wraith Ops (e.g., https://cdn.cbn.lol/12.41) to enable advanced neural capabilities.
                   </p>
                </div>
              </div>

              <div className="flex gap-4">
                <button 
                  onClick={() => setShowImportModal(false)}
                  className="flex-1 px-8 py-4 glass-pill bg-white/5 border-white/5 hover:bg-white/10 transition-all text-white font-bold text-sm uppercase tracking-widest"
                >
                  Cancel
                </button>
                <button 
                  onClick={handleImport}
                  disabled={isImporting || !importUrl.includes("12.41")}
                  className="flex-[2] px-8 py-4 bg-blue-600 hover:bg-blue-500 rounded-2xl text-white font-black text-sm uppercase tracking-widest transition-all disabled:opacity-20 disabled:cursor-not-allowed shadow-lg shadow-blue-500/20 flex items-center justify-center gap-3"
                >
                  {isImporting ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      Synchronizing...
                    </>
                  ) : (
                    "Authorize & Sync"
                  )}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <footer className="pt-20 text-center opacity-10">
         <p className="text-[10px] font-mono tracking-[0.8em] font-black italic">WRAITH CLOUD STORAGE // END-TO-END ENCRYPTED</p>
      </footer>
    </div>
  );
};
