import React from "react";
import { motion, AnimatePresence } from "motion/react";
import { Search, Trophy, Clock, Package, MoreHorizontal, TrendingUp } from "lucide-react";

export const StatsView = () => {
  const [builds, setBuilds] = React.useState<any[]>(() => {
    const saved = localStorage.getItem("wraith_builds");
    return saved ? JSON.parse(saved) : [];
  });

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 }
  };

  const hasBuilds = builds.length > 0;
  const mainBuild = hasBuilds ? builds[0] : null;

  return (
    <div className="flex-1 pt-32 pb-12 px-12 max-w-[1400px] mx-auto w-full space-y-12 text-white">
      <motion.h1 
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        className="text-7xl font-display font-black tracking-tight drop-shadow-xl italic"
      >
        Stats
      </motion.h1>

      <AnimatePresence>
        {!hasBuilds ? (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="h-[400px] glass-card flex flex-col items-center justify-center text-center p-12 border-dashed border-white/10"
          >
            <Clock className="w-16 h-16 text-white/10 mb-6" />
            <h2 className="text-3xl font-display font-black italic mb-4 opacity-80">Awaiting Tactical Data</h2>
            <p className="text-white/30 text-lg max-w-md font-light leading-relaxed">
              Import a build in the Library to begin tracking neural tactical statistics.
            </p>
          </motion.div>
        ) : (
          <div className="space-y-12">
            {/* Top Banner Stats */}
            <motion.div 
              variants={container}
              initial="hidden"
              animate="show"
              className="grid grid-cols-3 gap-6"
            >
               <motion.div 
                 variants={item}
                 className="col-span-2 glass-card p-10 relative overflow-hidden group hover:shadow-[0_0_40px_rgba(59,130,246,0.2)] transition-shadow"
               >
                  <div className="absolute inset-0 bg-gradient-to-br from-blue-500/5 to-purple-500/5 pointer-events-none" />
                  <motion.div 
                    animate={{ rotate: 360 }}
                    transition={{ repeat: Infinity, duration: 40, ease: "linear" }}
                    className="absolute -top-1/2 -right-1/4 w-full h-full bg-blue-500/5 blur-[100px] rounded-full"
                  />
                  <p className="text-sm font-mono font-bold uppercase tracking-[0.3em] text-white/40 mb-2">Total Time on Wraith</p>
                  <h2 className="text-8xl font-display font-black tracking-tighter leading-none italic flex items-baseline">
                      0h 00m
                      <motion.span 
                        animate={{ opacity: [0.3, 0.6, 0.3] }}
                        transition={{ repeat: Infinity, duration: 2 }}
                        className="text-2xl not-italic ml-4 text-blue-500/50"
                      >
                        <TrendingUp className="w-8 h-8" />
                      </motion.span>
                  </h2>
                  <p className="text-white/30 mt-6 text-sm">Real-time tracking synchronized for {mainBuild.name} {mainBuild.version}.</p>
               </motion.div>

               <motion.div 
                 variants={item}
                 className="glass-card p-10 flex flex-col justify-between hover:border-orange-500/30 transition-colors"
               >
                  <div>
                     <p className="text-xs font-bold uppercase tracking-widest text-white/40 mb-2">Live Tracking</p>
                     <h3 className="text-3xl font-display font-bold flex items-center gap-3">
                        Idle
                        <motion.div 
                          animate={{ scale: [1, 1.5, 1], opacity: [1, 0.5, 1] }}
                          transition={{ repeat: Infinity, duration: 2 }}
                          className="w-2.5 h-2.5 rounded-full bg-orange-400/20 status-glow" 
                        />
                     </h3>
                  </div>
                  <p className="text-sm text-white/30 leading-relaxed font-medium">Ready for deployment.</p>
               </motion.div>
            </motion.div>

            {/* Metrics Grid */}
            <motion.div 
              variants={container}
              initial="hidden"
              animate="show"
              className="grid grid-cols-3 gap-6 h-[240px]"
            >
               <motion.div 
                 variants={item}
                 whileHover={{ y: -10, scale: 1.02 }}
                 className="glass-card p-8 flex flex-col justify-between relative group overflow-hidden"
               >
                  <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-30 transition-opacity">
                      <Trophy className="w-24 h-24 text-blue-400 rotate-12" />
                  </div>
                  <div className="w-12 h-12 rounded-2xl bg-blue-500/10 flex items-center justify-center border border-blue-500/20 mb-4">
                     <Trophy className="w-6 h-6 text-blue-400" />
                  </div>
                  <div className="relative z-10">
                     <p className="text-[10px] items-center gap-1.5 uppercase font-bold text-white/30 tracking-widest mb-1 shadow-sm">Primary Build</p>
                     <h4 className="text-3xl font-display font-bold italic tracking-tight">{mainBuild.name} {mainBuild.version}</h4>
                     <p className="text-sm font-mono text-white/40 mt-1">Status: Operational</p>
                  </div>
               </motion.div>

               <motion.div 
                 variants={item}
                 whileHover={{ y: -10, scale: 1.02 }}
                 className="glass-card p-8 flex flex-col justify-between relative group"
               >
                  <div className="w-12 h-12 rounded-2xl bg-zinc-900 border border-white/5 flex items-center justify-center mb-4">
                     <Clock className="w-6 h-6 text-white/40" />
                  </div>
                  <div className="relative z-10">
                     <p className="text-[10px] opacity-40 uppercase font-bold tracking-widest mb-1">Tracked Nodes</p>
                     <h4 className="text-5xl font-display font-black italic">{builds.length}</h4>
                     <p className="text-sm text-white/30 mt-1">Active builds in local matrix.</p>
                  </div>
               </motion.div>

               <motion.div 
                 variants={item}
                 whileHover={{ y: -10, scale: 1.02 }}
                 className="glass-card p-8 flex flex-col justify-between relative group"
               >
                  <div className="w-12 h-12 rounded-2xl bg-zinc-900 border border-white/5 flex items-center justify-center mb-4">
                     <Package className="w-6 h-6 text-white/40" />
                  </div>
                  <div className="relative z-10">
                     <p className="text-[10px] opacity-40 uppercase font-bold tracking-widest mb-1">Storage Utilized</p>
                     <h4 className="text-5xl font-display font-black italic">{mainBuild.size.split(' ')[0]}</h4>
                     <p className="text-sm text-white/30 mt-1">Gigabytes of tactical data.</p>
                  </div>
               </motion.div>
            </motion.div>

            {/* List Area */}
            <motion.div 
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              className="space-y-6"
            >
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                   <h3 className="text-4xl font-display font-black italic tracking-tight text-white">Neural Runtime</h3>
                   <p className="text-sm text-white/40 font-medium">Synchronized per-build execution metrics.</p>
                </div>
              </div>

              {builds.map((build) => (
                <motion.div 
                  key={build.id}
                  whileHover={{ scale: 1.01 }}
                  className="glass-card p-8 flex items-center justify-between group"
                >
                   <div className="flex items-center gap-8 flex-1">
                      <motion.div 
                        whileHover={{ rotate: 5 }}
                        className="w-24 h-24 rounded-2xl overflow-hidden shadow-2xl relative group shrink-0"
                      >
                          <img src={build.image} alt="Thumb" className="w-full h-full object-cover" />
                      </motion.div>
                      <div className="space-y-4 flex-1">
                         <div className="flex items-center justify-between">
                            <h4 className="text-2xl font-display font-bold italic tracking-tight group-hover:text-blue-400 transition-colors">{build.name} {build.version} <span className="text-white/40 text-base font-mono not-italic ml-2">Synced</span></h4>
                            <span className="text-xs font-mono font-bold uppercase tracking-widest text-white/40">Integrity Check</span>
                         </div>
                         <div className="relative">
                            <div className="h-2 w-full bg-white/5 rounded-full overflow-hidden">
                               <motion.div 
                                 initial={{ width: 0 }}
                                 animate={{ width: '100%' }}
                                 transition={{ duration: 1.5, ease: "circOut" }}
                                 className="h-full bg-gradient-to-r from-blue-600 to-blue-400 rounded-full"
                               />
                            </div>
                            <div className="flex justify-between mt-2 font-mono text-[10px] font-bold uppercase tracking-widest text-blue-400">
                               <motion.span initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1 }}>0%</motion.span>
                               <motion.span initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 1.2 }} className="text-3xl font-display italic text-white/90">100%</motion.span>
                            </div>
                         </div>
                      </div>
                   </div>
                </motion.div>
              ))}
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
