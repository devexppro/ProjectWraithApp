import React, { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Send, Terminal as TerminalIcon, Sparkles, ChevronRight, Loader2 } from "lucide-react";

interface Message {
  role: "user" | "model";
  parts: [{ text: string }];
}

export const Terminal = () => {
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState<Message[]>([]);
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isTyping) return;

    const userMsg = input.trim();
    setInput("");
    
    const newMessages: Message[] = [...messages, { role: "user", parts: [{ text: userMsg }] }];
    setMessages(newMessages);
    setIsTyping(true);

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: userMsg, history: messages }),
      });
      const data = await res.json();
      
      if (data.text) {
        setMessages((prev) => [...prev, { role: "model", parts: [{ text: data.text }] }]);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className="flex flex-col h-full wraith-glass overflow-hidden">
      <div className="flex items-center justify-between px-4 py-3 border-b border-wraith-border bg-wraith-card/30">
        <div className="flex items-center gap-2">
          <TerminalIcon className="w-4 h-4 text-wraith-purple" />
          <span className="text-[10px] font-mono font-bold tracking-[0.2em] uppercase text-zinc-400">Wraith Core AI</span>
        </div>
        <div className="flex items-center gap-1.5">
          <div className="w-1.5 h-1.5 rounded-full bg-wraith-cyan animate-pulse" />
          <span className="text-[9px] font-mono text-wraith-cyan">ONLINE</span>
        </div>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-6 scrollbar-thin scrollbar-thumb-zinc-800 scrollbar-track-transparent">
        {messages.length === 0 && (
          <div className="h-full flex flex-col items-center justify-center text-center px-4 opacity-40">
             <div className="w-12 h-12 rounded-full border border-wraith-purple/30 flex items-center justify-center mb-4">
                <Sparkles className="w-6 h-6 text-wraith-purple" />
             </div>
             <p className="font-mono text-[10px] uppercase tracking-widest leading-relaxed">
               System active.<br/>Awaiting encrypted input sequence.
             </p>
          </div>
        )}
        <AnimatePresence mode="popLayout">
          {messages.map((msg, i) => (
            <motion.div
              layout
              key={i}
              initial={{ opacity: 0, x: msg.role === "user" ? 10 : -10 }}
              animate={{ opacity: 1, x: 0 }}
              className={`flex flex-col ${msg.role === "user" ? "items-end" : "items-start"}`}
            >
              <div className={`max-w-[90%] p-3 rounded-lg font-mono text-xs leading-relaxed ${
                msg.role === "user" 
                ? "bg-wraith-purple/20 border border-wraith-purple/30 text-white" 
                : "bg-zinc-900 border border-zinc-800 text-zinc-300"
              }`}>
                {msg.parts[0].text}
              </div>
              <span className="mt-1 text-[8px] uppercase tracking-tight text-zinc-600 font-mono">
                {msg.role === "user" ? "OPERATOR" : "WRAITH_CORE"}
              </span>
            </motion.div>
          ))}
        </AnimatePresence>
        {isTyping && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex items-center gap-2 text-zinc-600">
             <Loader2 className="w-3 h-3 animate-spin" />
             <span className="text-[10px] font-mono uppercase tracking-widest">Processing...</span>
          </motion.div>
        )}
      </div>

      <form onSubmit={handleSubmit} className="p-4 bg-wraith-card/40 border-t border-wraith-border">
        <div className="relative group">
          <ChevronRight className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-600 group-focus-within:text-wraith-purple transition-colors" />
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Execute command..."
            className="w-full bg-black/40 border border-zinc-800 rounded-lg py-3 pl-10 pr-12 focus:outline-none focus:ring-1 focus:ring-wraith-purple/50 focus:border-wraith-purple/50 text-xs font-mono text-white placeholder:text-zinc-700 transition-all"
          />
          <button
            type="submit"
            disabled={isTyping}
            className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 rounded-md bg-wraith-purple/10 text-wraith-purple hover:bg-wraith-purple hover:text-white transition-all disabled:opacity-50"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
        <div className="mt-2 flex justify-between px-1">
           <span className="text-[8px] text-zinc-700 font-mono">ENCRYPTION: AES-256-GCM</span>
           <span className="text-[8px] text-zinc-700 font-mono">LATENCY: 12ms</span>
        </div>
      </form>
    </div>
  );
};
