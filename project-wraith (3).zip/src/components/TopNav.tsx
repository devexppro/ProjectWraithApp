import React from "react";
import { motion, AnimatePresence } from "motion/react";
import { Home, Library as LibraryIcon, HardDrive, BarChart3, RotateCw, HelpCircle, Settings, LogOut, User as UserIcon } from "lucide-react";
import { useUser } from "./UserContext";

interface TopNavProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const TopNav = ({ activeTab, setActiveTab }: TopNavProps) => {
  const { user, loginWithDiscord, logout } = useUser();
  
  const tabs = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'library', label: 'Library', icon: LibraryIcon },
    { id: 'backend', label: 'Backend', icon: HardDrive },
    { id: 'stats', label: 'Stats', icon: BarChart3 },
  ];

  return (
    <header className="fixed top-0 left-0 right-0 z-50 p-6 flex flex-col items-center">
      <motion.div 
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="absolute top-2 text-[10px] uppercase tracking-[0.3em] font-bold text-white/40"
      >
        Stable 1.2.8
      </motion.div>
      
      <div className="w-full flex items-center justify-between max-w-[1400px]">
        {/* User Info Left */}
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="flex items-center gap-4"
        >
          <div className="w-12 h-12 rounded-2xl overflow-hidden border border-white/10 bg-zinc-900 group relative">
            {user ? (
              <img src={user.avatarUrl} alt="Profile" className="w-full h-full object-cover" />
            ) : (
              <div className="w-full h-full flex items-center justify-center text-white/20">
                <UserIcon className="w-6 h-6" />
              </div>
            )}
          </div>
          <div className="flex flex-col">
            <h2 className="text-xl font-display font-medium tracking-tight">
              {user ? `Welcome, ${user.username}` : 'Project Wraith UI'}
            </h2>
            <div className="flex items-center gap-2">
               <div className={`w-1.5 h-1.5 rounded-full ${user ? 'bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.6)]' : 'bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.6)]'}`} />
               <span className="text-[10px] font-mono text-white/30 uppercase tracking-widest">
                 {user ? 'AUTHENTICATED' : 'GUEST_MODE'}
               </span>
            </div>
          </div>
        </motion.div>

        {/* Center Pill Nav */}
        <motion.nav 
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ type: "spring", damping: 20, stiffness: 300, delay: 0.1 }}
          className="glass-pill p-1.5 flex items-center gap-1"
        >
          {/* Logo Placeholder */}
          <motion.div 
            whileHover={{ rotate: 180 }}
            className="p-2 ml-1 mr-2 bg-gradient-to-br from-blue-400 to-purple-500 rounded-xl overflow-hidden shrink-0 cursor-pointer"
          >
             <div className="w-6 h-6 flex items-center justify-center">
                <div className="w-4 h-4 border-2 border-white rounded-full relative">
                   <div className="absolute inset-0 border-t-2 border-white/50 -rotate-45" />
                </div>
             </div>
          </motion.div>
          
          {tabs.map((tab, i) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-6 py-2.5 rounded-full text-sm font-medium transition-all relative group ${
                  isActive ? 'text-white' : 'text-white/40 hover:text-white/60'
                }`}
              >
                {isActive && (
                  <motion.div
                    layoutId="nav-bg"
                    className="absolute inset-0 bg-zinc-800/80 shadow-inner shadow-white/5 rounded-full"
                    transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
                  />
                )}
                <Icon className={`w-4 h-4 relative z-10 transition-colors ${isActive ? 'text-blue-400' : 'group-hover:text-blue-400/50'}`} />
                <span className="relative z-10">{tab.label}</span>
              </button>
            );
          })}

          <div className="w-12 h-10 rounded-full overflow-hidden border border-white/10 ml-2 bg-zinc-900 flex items-center justify-center opacity-40">
             <div className="w-4 h-4 border-2 border-white/20 rounded-full" />
          </div>
        </motion.nav>

        {/* Right Actions */}
        <motion.div 
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="flex items-center gap-6"
        >
           <motion.button whileHover={{ rotate: 90 }} className="text-white/40 hover:text-white transition-colors cursor-pointer"><RotateCw className="w-5 h-5" /></motion.button>
           <motion.button whileHover={{ scale: 1.1 }} className="text-white/40 hover:text-white transition-colors cursor-pointer"><HelpCircle className="w-5 h-5" /></motion.button>
           
           {user ? (
             <motion.button 
               whileHover={{ scale: 1.1, color: '#ef4444' }}
               onClick={logout}
               className="text-white/40 transition-colors cursor-pointer"
             >
               <LogOut className="w-5 h-5" />
             </motion.button>
           ) : (
             <motion.button 
               whileHover={{ scale: 1.1 }}
               onClick={loginWithDiscord}
               className="text-white/40 hover:text-blue-400 transition-colors cursor-pointer"
             >
               <Settings className="w-5 h-5" />
             </motion.button>
           )}
        </motion.div>
      </div>
    </header>
  );
};
