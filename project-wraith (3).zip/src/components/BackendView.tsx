import React from "react";
import { motion } from "motion/react";
import { Info, Terminal, ChevronDown, Rocket, ShieldCheck, RotateCcw } from "lucide-react";

export const BackendView = () => {
  return (
    <div className="flex-1 pt-32 pb-12 px-12 max-w-[1400px] mx-auto w-full space-y-8">
      <h1 className="text-7xl font-display font-black tracking-tight drop-shadow-xl">Backend</h1>

      {/* Status Banner */}
      <div className="bg-red-500/10 border border-red-500/20 p-5 rounded-2xl flex items-center justify-between">
        <div className="flex items-center gap-3">
           <div className="w-2.5 h-2.5 rounded-full bg-red-500 status-glow" />
           <span className="text-sm font-bold opacity-80 uppercase tracking-widest">Backend not detected</span>
        </div>
        <span className="text-[10px] font-mono text-white/30 uppercase tracking-[0.2em]">Waiting on 127.0.0.1:3551</span>
      </div>

      {/* Info Panel */}
      <div className="glass-card p-4 space-y-1">
         <div className="flex items-center gap-3 p-4 bg-white/5 rounded-xl text-sm border border-white/5">
            <Info className="w-5 h-5 text-blue-400" />
            <div className="flex-1">
               <span className="font-bold">Quick tip</span>
               <span className="mx-2 opacity-40 italic">1/3</span>
               <p className="text-white/60 mt-0.5">Running your own backend? Keep Type on Local so Wraith uses your local server settings.</p>
            </div>
            <button className="p-2 hover:bg-white/10 rounded-lg transition-colors"><ChevronDown className="w-5 h-5 opacity-40 rotate-180" /></button>
         </div>
      </div>

      {/* Form Area */}
      <div className="glass-card p-10 space-y-10">
         <div className="grid grid-cols-2 gap-20">
            {/* Type Selection */}
            <div className="flex items-center gap-6">
               <div className="p-4 bg-zinc-900 border border-white/5 rounded-2xl shrink-0">
                  <Terminal className="w-6 h-6 text-white/40" />
               </div>
               <div className="flex-1 space-y-1">
                  <h4 className="font-bold text-lg">Type</h4>
                  <p className="text-xs text-white/40">Choose Local for a local backend or Remote for another host</p>
               </div>
               <div className="relative w-48">
                  <select className="appearance-none w-full bg-zinc-900 border border-white/10 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/30 transition-all font-medium">
                     <option>Local</option>
                     <option>Remote</option>
                  </select>
                  <ChevronDown className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 pointer-events-none opacity-40" />
               </div>
            </div>

            {/* Port Entry */}
            <div className="flex items-center gap-6">
               <div className="p-4 bg-zinc-900 border border-white/5 rounded-2xl shrink-0 text-white/40 text-xl font-bold italic font-mono">
                  #
               </div>
               <div className="flex-1 space-y-1">
                  <h4 className="font-bold text-lg">Port</h4>
                  <p className="text-xs text-white/40">The port of the backend</p>
               </div>
               <input 
                 type="text" 
                 defaultValue="3551" 
                 className="w-48 bg-zinc-900 border border-white/10 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/30 transition-all text-right font-medium"
               />
            </div>
         </div>

         {/* Actions */}
         <div className="flex items-center justify-between pt-6 border-t border-white/5">
            <div className="flex gap-4">
              <button className="btn-primary">
                <Rocket className="w-5 h-5" />
                Launch WRAITH Backend
              </button>
              <button className="btn-secondary rounded-full flex items-center gap-2 font-bold px-8 py-3">
                 <ShieldCheck className="w-5 h-5 text-blue-400" />
                 Check backend
              </button>
            </div>
            <button className="flex items-center gap-2 text-white/40 hover:text-white transition-colors text-sm font-bold uppercase tracking-widest px-4">
               <RotateCcw className="w-4 h-4" />
               Reset
            </button>
         </div>
      </div>
    </div>
  );
};
