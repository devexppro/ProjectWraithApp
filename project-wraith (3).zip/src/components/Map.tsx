import React from "react";
import { motion } from "motion/react";

export const TacticalMap = () => {
  return (
    <div className="relative w-full h-full min-h-[400px] overflow-hidden rounded-2xl bg-[#080808] border border-wraith-border group">
      {/* Background Grid */}
      <div className="absolute inset-0 opacity-[0.03] pointer-events-none" 
           style={{ backgroundImage: 'radial-gradient(#fff 1px, transparent 1px)', backgroundSize: '30px 30px' }} />
      
      {/* Scanline Effect */}
      <div className="absolute inset-0 scanline pointer-events-none" />

      {/* Abstract World/Tactical SVG */}
      <svg className="w-full h-full p-12 overflow-visible" viewBox="0 0 800 400" fill="none">
        <defs>
          <radialGradient id="nodeGlow" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#8b5cf6" stopOpacity="0.4" />
            <stop offset="100%" stopColor="#8b5cf6" stopOpacity="0" />
          </radialGradient>
        </defs>

        {/* Abstract "Land" connections */}
        <path d="M100 200 Q 200 100 300 200 T 500 200" stroke="rgba(139,92,246,0.1)" strokeWidth="1" strokeDasharray="5 5" />
        <path d="M200 300 Q 400 350 600 250" stroke="rgba(139,92,246,0.05)" strokeWidth="1" />
        
        {/* Active Nodes */}
        {[
          { x: 150, y: 120, label: "NZ_GHOST" },
          { x: 450, y: 180, label: "MAIN_FRAME" },
          { x: 300, y: 320, label: "DEEP_CORE" },
          { x: 650, y: 140, label: "SAT_LINK" }
        ].map((node, i) => (
          <g key={i}>
            <circle cx={node.x} cy={node.y} r="15" fill="url(#nodeGlow)" className="animate-pulse" />
            <motion.circle
              cx={node.x}
              cy={node.y}
              r="4"
              fill="#8b5cf6"
              initial={{ scale: 0 }}
              animate={{ scale: [1, 1.5, 1] }}
              transition={{ repeat: Infinity, duration: 2, delay: i * 0.5 }}
            />
            <text x={node.x + 10} y={node.y + 15} fill="rgba(255,255,255,0.2)" fontSize="8" fontFamily="monospace">
              {node.label}
            </text>
          </g>
        ))}

        {/* Pulse Waves */}
        <motion.circle
          cx="450"
          cy="180"
          r="0"
          stroke="#8b5cf6"
          strokeWidth="0.5"
          animate={{ r: [0, 150], opacity: [0.5, 0] }}
          transition={{ repeat: Infinity, duration: 4, ease: "easeOut" }}
        />
      </svg>

      {/* Overlays */}
      <div className="absolute top-6 left-6 flex flex-col gap-1">
        <span className="text-[10px] font-mono font-bold text-wraith-purple uppercase tracking-[0.2em]">Global Feed</span>
        <span className="text-[24px] font-display text-white tracking-widest uppercase">7 ACTIVE NODES</span>
      </div>

      <div className="absolute bottom-6 right-6 text-right">
        <p className="text-[10px] font-mono text-zinc-600 mb-2">TARGET COORDINATES</p>
        <div className="flex gap-2">
          <div className="px-3 py-1 bg-zinc-900 border border-zinc-800 rounded font-mono text-xs text-white">45.02° N</div>
          <div className="px-3 py-1 bg-zinc-900 border border-zinc-800 rounded font-mono text-xs text-white">123.41° W</div>
        </div>
      </div>
      
      {/* HUD Accents */}
      <div className="absolute top-0 left-0 w-2 h-2 border-t border-l border-wraith-purple/50" />
      <div className="absolute top-0 right-0 w-2 h-2 border-t border-r border-wraith-purple/50" />
      <div className="absolute bottom-0 left-0 w-2 h-2 border-b border-l border-wraith-purple/50" />
      <div className="absolute bottom-0 right-0 w-2 h-2 border-b border-r border-wraith-purple/50" />
    </div>
  );
};
