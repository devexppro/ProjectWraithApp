import React from "react";
import { motion, useAnimation } from "motion/react";
import { Play, Shield, Zap, Target } from "lucide-react";
import { useUser } from "./UserContext";

export const HomeView = () => {
  const { user, loginWithDiscord } = useUser();
  const controls = useAnimation();

  const handleLogoHover = () => {
    controls.start({
      scale: [1, 1.05, 0.98, 1.02, 1],
      rotate: [0, 5, -5, 2, 0],
      transition: { duration: 0.5 }
    });
  };

  return (
    <div className="flex-1 flex flex-col items-center justify-center pt-24 pb-12 px-6 relative">
      <motion.div 
        initial={{ opacity: 0, y: 50, scale: 0.9 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ type: "spring", damping: 15, stiffness: 100 }}
        className="w-full max-w-7xl h-[600px] glass-card overflow-hidden relative group"
      >
        {/* Full Card Background Image */}
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          <img 
            src="https://imageio.forbes.com/specials-images/imageserve/5e4e80dd7a0098000733cb70/Fortnite-Chapter-2-Season-2-Battle-Pass-Skins/0x0.jpg?width=960&dpr=1" 
            alt="Hero Background" 
            className="w-full h-full object-cover opacity-60 scale-105 group-hover:scale-100 transition-transform duration-1000"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black via-black/40 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent" />
        </div>
        
        {/* Decorative Elements */}
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none select-none opacity-20">
            <motion.div 
              animate={controls}
              className="relative w-full h-full"
            >
                <div className="absolute inset-0 flex items-center justify-center">
                    <motion.div 
                      animate={{ 
                        opacity: [0.1, 0.2, 0.1],
                        scale: [1, 1.1, 1],
                      }}
                      transition={{ repeat: Infinity, duration: 10, ease: "linear" }}
                      className="w-[800px] h-[800px] bg-blue-500/10 rounded-full blur-[120px]" 
                    />
                </div>
            </motion.div>
        </div>

        {/* Content Overlay */}
        <div className="absolute inset-0 p-20 flex flex-col justify-end bg-gradient-to-t from-black/90 via-transparent to-transparent">
          <div className="max-w-2xl space-y-8">
            <div className="space-y-2">
              <motion.h1 
                initial={{ opacity: 0, x: -50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.3 }}
                className="text-8xl font-display font-black tracking-tighter uppercase leading-none drop-shadow-2xl"
              >
                {user ? "WRAITH" : "PROJECT"} <span className="block text-white/90">{user ? "Active" : "WRAITH"}</span>
              </motion.h1>
              
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.5 }}
                className="flex items-center gap-4 py-2"
              >
                  {[
                    { icon: Zap, text: "ULTRA LOW LATENCY" },
                    { icon: Target, text: "NEURAL TRACKING" },
                    { icon: Shield, text: "GHOST DATA" }
                  ].map((item, i) => (
                    <div key={i} className="flex items-center gap-1.5 px-3 py-1 bg-white/5 border border-white/10 rounded-full">
                       <item.icon className="w-3 h-3 text-blue-400" />
                       <span className="text-[9px] font-mono font-bold tracking-widest text-white/50">{item.text}</span>
                    </div>
                  ))}
              </motion.div>
            </div>
            
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
              className="space-y-6"
            >
              <p className="text-xl text-white/50 leading-relaxed font-light max-w-lg">
                {user 
                  ? "Welcome back to the Wraith Core. All tactical systems are operational and awaiting your command sequence."
                  : "Wraith Core requires Discord identity verification to enable advanced tactical AI protocols."
                }
              </p>
              
              <div className="flex items-center gap-4">
                {user ? (
                  <motion.button 
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="btn-primary group !px-8 !py-4 !text-lg"
                  >
                    <Play className="fill-current w-6 h-6 group-hover:scale-110 transition-transform" />
                    Enter Control Core
                  </motion.button>
                ) : (
                  <motion.button 
                    whileHover={{ 
                      scale: 1.05,
                      boxShadow: "0 0 20px rgba(88, 101, 242, 0.4)"
                    }}
                    whileTap={{ scale: 0.95 }}
                    onClick={loginWithDiscord}
                    className="px-8 py-4 bg-[#5865F2] hover:bg-[#4752C4] rounded-2xl font-black text-lg transition-all flex items-center gap-3 shadow-xl"
                  >
                    <svg className="w-6 h-6 fill-current" viewBox="0 0 24 24">
                      <path d="M20.317 4.3698a19.7913 19.7913 0 00-4.8851-1.5152.0741.0741 0 00-.0785.0371c-.211.3753-.4447.8648-.6083 1.2495-1.8447-.2762-3.68-.2762-5.4868 0-.1636-.3933-.4058-.8742-.6177-1.2495a.077.077 0 00-.0785-.037 19.7363 19.7363 0 00-4.8852 1.515.0699.0699 0 00-.0321.0277C.5334 9.0458-.319 13.5799.0992 18.0578a.0824.0824 0 00.0312.0561c2.0528 1.5076 4.0413 2.4228 5.9929 3.0294a.0777.0777 0 00.0842-.0276c.4616-.6304.8731-1.2952 1.226-1.9942a.076.076 0 00-.0416-.1057c-.6528-.2476-1.2743-.5495-1.8722-.8923a.077.077 0 01-.0076-.1277c.1258-.0943.2517-.1923.3718-.2914a.0743.0743 0 01.0775-.0105c3.9278 1.7933 8.18 1.7933 12.0614 0a.0739.0739 0 01.0785.0095c.1202.099.246.1971.3728.2924a.077.077 0 01-.0066.1276 12.2986 12.2986 0 01-1.873.8914.0766.0766 0 00-.0407.1067c.3604.698.7719 1.3628 1.225 1.9932a.076.076 0 00.0842.0286c1.961-.6067 3.9495-1.5219 6.0023-3.0294a.077.077 0 00.0313-.0552c.5004-5.177-.8382-9.6739-3.5485-13.6604a.061.061 0 00-.0312-.0286zM8.02 15.3312c-1.1825 0-2.1569-1.0857-2.1569-2.419 0-1.3332.9555-2.4189 2.157-2.4189 1.2108 0 2.1757 1.0952 2.1568 2.419 0 1.3332-.9555 2.4189-2.1569 2.4189zm7.9748 0c-1.1825 0-2.1569-1.0857-2.1569-2.419 0-1.3332.9554-2.4189 2.1569-2.4189 1.2108 0 2.1757 1.0952 2.1568 2.419 0 1.3332-.946 2.4189-2.1568 2.4189z"/>
                    </svg>
                    Identify with Discord
                  </motion.button>
                )}
                
                <button className="btn-secondary !px-8 !py-4 opacity-50 hover:opacity-100 transition-opacity">
                  System Specs
                </button>
              </div>
            </motion.div>
          </div>
        </div>

        {/* Indicators */}
        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 flex gap-3">
          <motion.div 
            animate={{ width: [12, 48, 12] }}
            transition={{ repeat: Infinity, duration: 3 }}
            className="h-1.5 rounded-full bg-blue-500 shadow-[0_0_10px_rgba(59,130,246,0.5)]" 
          />
          <div className="w-3 h-1.5 rounded-full bg-white/20" />
          <div className="w-3 h-1.5 rounded-full bg-white/20" />
        </div>
      </motion.div>
    </div>
  );
};
