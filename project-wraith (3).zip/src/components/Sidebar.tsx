import React from "react";
import { motion } from "motion/react";
import { Shield, Target, Zap, Activity, Grid3X3, Users, Settings, Database } from "lucide-react";

const SidebarItem = ({ icon: Icon, label, active = false }: { icon: any, label: string, active?: boolean }) => (
  <motion.button
    whileHover={{ x: 4 }}
    className={`w-full flex items-center gap-3 px-4 py-3 text-sm transition-colors relative group ${
      active ? "text-white" : "text-zinc-500 hover:text-zinc-300"
    }`}
  >
    {active && (
      <motion.div
        layoutId="active-nav"
        className="absolute left-0 w-1 h-6 bg-wraith-purple rounded-r-full shadow-[0_0_10px_rgba(139,92,246,0.5)]"
      />
    )}
    <Icon className={`w-5 h-5 ${active ? "text-wraith-purple" : "group-hover:text-wraith-purple"}`} />
    <span className="font-medium tracking-tight">{label}</span>
  </motion.button>
);

export const Sidebar = () => {
  return (
    <div className="h-full w-64 border-r border-wraith-border bg-wraith-bg flex flex-col pt-8">
      <div className="px-8 mb-12">
        <div className="flex items-center gap-2 mb-1">
          <div className="w-6 h-6 bg-wraith-purple rotate-45 flex items-center justify-center">
            <div className="w-2 h-2 bg-white -rotate-45" />
          </div>
          <h1 className="font-display text-xl tracking-tighter text-white">PROJECT<span className="text-wraith-purple">WRAITH</span></h1>
        </div>
        <p className="text-[10px] uppercase tracking-[0.2em] text-zinc-600 font-mono">Stealth AI OS v0.1.0</p>
      </div>

      <div className="flex-1 space-y-1">
        <div className="px-6 mb-4">
          <p className="text-[10px] uppercase tracking-[0.2em] text-zinc-700 font-mono font-bold">Main Console</p>
        </div>
        <SidebarItem icon={Activity} label="Overview" active />
        <SidebarItem icon={Target} label="Infiltration" />
        <SidebarItem icon={Shield} label="Ghost Nodes" />
        <SidebarItem icon={Zap} label="Pulse Scans" />
        <SidebarItem icon={Grid3X3} label="Asset Grid" />
        
        <div className="px-6 mt-8 mb-4">
          <p className="text-[10px] uppercase tracking-[0.2em] text-zinc-700 font-mono font-bold">System Data</p>
        </div>
        <SidebarItem icon={Users} label="Team Alpha" />
        <SidebarItem icon={Database} label="Central Core" />
        <SidebarItem icon={Settings} label="Ops Settings" />
      </div>

      <div className="p-6 border-t border-wraith-border">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-zinc-800 border border-zinc-700 overflow-hidden">
             <img src="https://api.dicebear.com/7.x/bottts-neutral/svg?seed=Wraith" alt="User" />
          </div>
          <div>
            <p className="text-xs font-bold text-white leading-none">OPERATOR</p>
            <p className="text-[10px] text-zinc-500 font-mono">STATUS: HIDDEN</p>
          </div>
        </div>
      </div>
    </div>
  );
};
