import React, { useEffect, useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ShieldCheck, AlertTriangle, Cpu } from "lucide-react";

interface Node {
  id: string;
  status: string;
  load: number;
}

export const TacticalGrid = () => {
  const [nodes, setNodes] = useState<Node[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await fetch("/api/tactical");
        const data = await res.json();
        setNodes(data.nodes);
        setLoading(false);
      } catch (err) {
        console.error(err);
      }
    };
    fetchData();
    const interval = setInterval(fetchData, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xs uppercase tracking-[0.3em] font-mono font-bold text-zinc-500">Node Status Grid</h2>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
             <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]" />
             <span className="text-[10px] font-mono text-zinc-400">NOMINAL</span>
          </div>
          <div className="flex items-center gap-2">
             <div className="w-1.5 h-1.5 rounded-full bg-wraith-purple animate-pulse" />
             <span className="text-[10px] font-mono text-zinc-400">ENCRYPTING</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-1">
        <AnimatePresence mode="popLayout">
          {nodes.map((node, i) => (
            <motion.div
              layout
              key={node.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className="group relative wraith-glass p-4 overflow-hidden"
            >
              <div className="absolute top-0 right-0 p-1">
                <Cpu className="w-3 h-3 text-zinc-800 group-hover:text-wraith-purple/50 transition-colors" />
              </div>
              
              <div className="flex items-center justify-between mb-3">
                <span className="font-mono text-xs font-bold text-zinc-300">{node.id}</span>
                <span className={`text-[10px] uppercase font-mono px-1.5 py-0.5 rounded ${
                  node.status === "Active" ? "bg-emerald-500/10 text-emerald-500" : "bg-wraith-purple/10 text-wraith-purple"
                }`}>
                  {node.status}
                </span>
              </div>

              <div className="space-y-1">
                <div className="flex justify-between text-[10px] font-mono text-zinc-500 uppercase">
                  <span>System Load</span>
                  <span>{node.load}%</span>
                </div>
                <div className="h-1 bg-zinc-900 overflow-hidden relative">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${node.load}%` }}
                    className={`h-full absolute left-0 top-0 ${
                      node.load > 80 ? "bg-red-500" : node.load > 50 ? "bg-wraith-purple" : "bg-emerald-500"
                    }`}
                  />
                </div>
              </div>

              <div className="mt-4 flex items-center justify-between pt-4 border-t border-zinc-800/50">
                 <div className="flex items-center gap-1.5">
                    <ShieldCheck className="w-3 h-3 text-emerald-500/50" />
                    <span className="text-[9px] text-zinc-600 font-mono">ENCRYPTED</span>
                 </div>
                 <div className="flex items-center gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button className="text-[9px] text-wraith-purple font-bold uppercase transition-colors hover:text-white">REBOOT</button>
                    <span className="text-zinc-800 text-[10px]">/</span>
                    <button className="text-[9px] text-zinc-500 font-bold uppercase transition-colors hover:text-white">REMAP</button>
                 </div>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
};
