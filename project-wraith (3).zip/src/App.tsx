import React, { useState } from "react";
import { TopNav } from "./components/TopNav";
import { HomeView } from "./components/HomeView";
import { LibraryView } from "./components/LibraryView";
import { BackendView } from "./components/BackendView";
import { StatsView } from "./components/StatsView";
import { motion, AnimatePresence } from "framer-motion";

export default function App() {
  const [activeTab, setActiveTab] = useState("home");

  const renderContent = () => {
    // Explicit keys ensure Framer Motion animations trigger on tab change
    const views = {
      home: <HomeView key="home" />,
      library: <LibraryView key="library" />,
      backend: <BackendView key="backend" />,
      stats: <StatsView key="stats" />
    };
    return views[activeTab] || <HomeView key="home" />;
  };

  return (
    <div className="min-h-screen w-full bg-[#0d1117] text-[#c9d1d9] selection:bg-blue-500/30 flex flex-col overflow-hidden">
      
      {/* Global Background Image */}
      <div className="fixed inset-0 pointer-events-none z-0">
        <img 
          src="https://fortnitenews.com/content/images/2020/02/image-19.png" 
          alt="Background" 
          className="w-full h-full object-cover opacity-40 grayscale-[0.2]"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#0d1117]/80 to-[#0d1117]" />
      </div>

      {/* Navigation */}
      <div className="relative z-50">
        <TopNav activeTab={activeTab} setActiveTab={setActiveTab} />
      </div>

      {/* Main Content Area */}
      <main className="flex-1 relative z-10 overflow-hidden">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 8, scale: 0.99 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -8, scale: 0.99 }}
            transition={{ 
              duration: 0.25, 
              ease: [0.23, 1, 0.32, 1] 
            }}
            className="h-full w-full p-6"
          >
            {renderContent()}
          </motion.div>
        </AnimatePresence>
      </main>
      
      {/* Subtle Brand Footer */}
      <footer className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 pointer-events-none opacity-30">
         <p className="text-[10px] font-mono tracking-[0.8em] uppercase font-bold text-blue-200/50">
           Project Wraith Link // Stable Build
         </p>
      </footer>
    </div>
  );
}